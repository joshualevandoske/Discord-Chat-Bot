Follow along: https://youtu.be/aNzc8BsPIkQ

1. Check what models are running on Ollama: ```ollama ps```
2. Npm install: ```npm install```
