import {
  createAudioPlayer,
  createAudioResource,
  entersState,
  getVoiceConnection,
  AudioPlayerStatus,
  VoiceConnectionStatus
} from '@discordjs/voice';
import path from 'path';
import { createReadStream } from 'fs';

export async function playAudioInChannel(guildId: string, file: string): Promise<void> {
  const connection = getVoiceConnection(guildId);

  if (!connection) {
    console.error("❌ Not connected to a voice channel.");
    return;
  }

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 5_000);

    const player = createAudioPlayer();
    const resource = createAudioResource(createReadStream(file), {
      inlineVolume: true
    });

    connection.subscribe(player);
    player.play(resource);

    console.log("🔊 Playing:", file);

    await entersState(player, AudioPlayerStatus.Idle, 30_000);
    player.stop();
    console.log("✅ Finished playback.");
  } catch (err) {
    console.error("❌ Playback failed:", err);
  }
}