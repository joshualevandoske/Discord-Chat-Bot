import {
  VoiceConnection,
  EndBehaviorType,
  getVoiceConnection
} from '@discordjs/voice';

import prism from 'prism-media';
import fs from 'fs';
import { join } from 'path';

export function startAudioCapture(guildId: string, userId: string) {
  const connection = getVoiceConnection(guildId);
  if (!connection) {
    console.error("❌ Bot is not connected to a voice channel.");
    return;
  }

  const receiver = connection.receiver;

  const opusStream = receiver.subscribe(userId, {
    end: {
      behavior: EndBehaviorType.AfterSilence,
      duration: 1000
    }
  });

  const filename = join(__dirname, `../../recordings/${userId}-${Date.now()}.pcm`);
  const outputStream = fs.createWriteStream(filename);

  const pcmStream = new prism.opus.Decoder({
    rate: 48000,
    channels: 2,
    frameSize: 960
  });

  opusStream.pipe(pcmStream).pipe(outputStream);

  console.log(`🎙️ Recording audio from user ${userId} to ${filename}`);

  outputStream.on('finish', () => {
    console.log(`✅ Finished recording ${filename}`);
  });
}