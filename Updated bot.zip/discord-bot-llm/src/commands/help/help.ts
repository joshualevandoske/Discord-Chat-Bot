import { SlashCommandBuilder } from 'discord.js';

export const data = new SlashCommandBuilder()
  .setName('help')
  .setDescription('Shows how to use the AI voice bot and available commands.');

export async function execute(interaction: any) {
  const helpMessage = `
**ChatBot Help**
The bot listens for a wake word in a voice channel, captures your message, and responds with a generated reply in the chosen personalitie's voice.

**📝 Commands:**
- \`/prompt [your message]\` — Ask the AI something directly
- \`/help\` — Display this help message
- \`/join\` — Join your current voice channel
- \`/leave\` — Leave the voice channel

**❓Need help?**
Make sure you’re in a voice channel and the bot is online.
  `;

  await interaction.reply(helpMessage);
}