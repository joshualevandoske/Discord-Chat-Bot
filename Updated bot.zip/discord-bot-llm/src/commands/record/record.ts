import { SlashCommandBuilder, CommandInteraction } from 'discord.js';
import { startAudioCapture } from '../../audio/receiver';

export const data = new SlashCommandBuilder()
  .setName('record')
  .setDescription('Starts recording your voice in the current channel.');

export async function execute(interaction: CommandInteraction) {
  const userId = interaction.user.id;
  const guildId = interaction.guildId;

  if (!interaction.guild || !interaction.member || !guildId) {
    return interaction.reply('❌ This command must be used in a server.');
  }

  // Start listening to the user's audio
  startAudioCapture(guildId, userId);

  await interaction.reply('🎙️ Started recording your voice...');
}