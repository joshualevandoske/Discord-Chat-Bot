import {
  SlashCommandBuilder,
  CommandInteraction,
  GuildMember,
  VoiceBasedChannel
} from 'discord.js';
import {
  joinVoiceChannel,
  entersState,
  VoiceConnectionStatus
} from '@discordjs/voice';

export const data = new SlashCommandBuilder()
  .setName('join')
  .setDescription('Bot joins your current voice channel.');

export async function execute(interaction: CommandInteraction) {
  const member = interaction.member as GuildMember;
  const voiceChannel = member.voice?.channel as VoiceBasedChannel | null;


  if (!voiceChannel) {
    return interaction.reply({
      content: '❌ You must be in a voice channel first.',
      ephemeral: true
    });
  }

  try {
    const connection = joinVoiceChannel({
      channelId: voiceChannel.id,
      guildId: voiceChannel.guild.id,
      adapterCreator: voiceChannel.guild.voiceAdapterCreator,
      selfDeaf: false,
    });

    // Wait for the connection to be ready (up to 5 seconds)
    await entersState(connection, VoiceConnectionStatus.Ready, 5_000);

    await interaction.reply(`✅ Joined ${voiceChannel.name}!`);
  } catch (error) {
    console.error("❌ Error joining voice channel:", error);
    await interaction.reply({
      content: `❌ Failed to join ${voiceChannel.name}: ${error}`,
      ephemeral: true
    });
  }
}