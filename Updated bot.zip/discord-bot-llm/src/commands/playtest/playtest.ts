import { SlashCommandBuilder, CommandInteraction } from 'discord.js';
import { getVoiceConnection, createAudioPlayer, createAudioResource, entersState, AudioPlayerStatus, VoiceConnectionStatus } from '@discordjs/voice';
import path from 'path';
import { createReadStream } from 'fs';

export const data = new SlashCommandBuilder()
  .setName('playtest')
  .setDescription('Plays the latest response.mp3 in the current voice channel');

export async function execute(interaction: CommandInteraction) {
  const guildId = interaction.guildId!;
  const connection = getVoiceConnection(guildId);

  if (!connection) {
    return interaction.reply('❌ I\'m not connected to a voice channel. Use `/join` first.');
  }

  try {
    await entersState(connection, VoiceConnectionStatus.Ready, 5_000);

    const filePath = path.join(__dirname, '../../../audio/response.mp3');
    const resource = createAudioResource(createReadStream(filePath));
    const player = createAudioPlayer();

    connection.subscribe(player);
    player.play(resource);

    await interaction.reply('🔊 Playing `response.mp3` in your voice channel...');

    player.on(AudioPlayerStatus.Idle, () => {
      player.stop();
      console.log("✅ Playback finished.");
    });

  } catch (err) {
    console.error('❌ Error playing audio:', err);
    await interaction.reply('❌ Failed to play audio.');
  }
}