import { SlashCommandBuilder, CommandInteraction, GuildMember } from 'discord.js';
import { getVoiceConnection } from '@discordjs/voice';

export const data = new SlashCommandBuilder()
  .setName('leave')
  .setDescription('Bot leaves the current voice channel.');

export async function execute(interaction: CommandInteraction) {
  const guildId = interaction.guildId!;
  const connection = getVoiceConnection(guildId);

  if (!connection) {
    return interaction.reply("❌ I'm not in a voice channel.");
  }

  connection.destroy();
  await interaction.reply("👋 Left the voice channel.");
}