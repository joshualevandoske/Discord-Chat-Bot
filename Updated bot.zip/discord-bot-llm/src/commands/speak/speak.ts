import { SlashCommandBuilder, CommandInteraction } from 'discord.js';
import { startAudioCapture } from '../../audio/receiver';
import { queryOllama } from '../../llm/ollamaClient';
import { textToSpeech } from '../../tts/elevenLabsClient';
import { playAudioInChannel } from '../../audio/playback';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

export const data = new SlashCommandBuilder()
  .setName('speak')
  .setDescription('Record, transcribe, generate a Walter White response, and play it in voice chat');

export async function execute(interaction: CommandInteraction) {
  const now = () => new Date().getTime();
  const logStep = (label: string, start: number) =>
    console.log(`⏱️ ${label} took ${now() - start} ms`);

  const globalStart = now();

  const guild = interaction.guild!;
  const userId = interaction.user.id;

  const recordingsDir = path.join(__dirname, '../../../recordings');
  const wavsDir = path.join(__dirname, '../../../wavs');
  const audioOutPath = path.join(__dirname, '../../../audio/response.mp3');

  if (!fs.existsSync(recordingsDir)) fs.mkdirSync(recordingsDir);
  if (!fs.existsSync(wavsDir)) fs.mkdirSync(wavsDir);

  await interaction.reply('🎙️ Recording...');

  // Step 1: Record
  const t1 = now();
  startAudioCapture(guild.id, userId);
  await new Promise(res => setTimeout(res, 6000));
  logStep('Recording', t1);

  // Step 2: Find latest .pcm
  const pcmFiles = fs.readdirSync(recordingsDir)
    .filter(f => f.endsWith('.pcm') && f.includes(userId))
    .map(f => ({
      name: f,
      time: fs.statSync(path.join(recordingsDir, f)).mtime.getTime()
    }))
    .sort((a, b) => b.time - a.time);

  if (pcmFiles.length === 0) {
    return interaction.editReply('❌ No audio recorded.');
  }

  const latestPcm = path.join(recordingsDir, pcmFiles[0].name);
  const wavPath = path.join(wavsDir, pcmFiles[0].name.replace('.pcm', '.wav'));
  const baseName = path.basename(wavPath, '.wav');
  const txtFile = path.join(wavsDir, `${baseName}.txt`);

  // Step 3: Convert PCM → WAV
  const t2 = now();
  try {
    execSync(`ffmpeg -f s16le -ar 48000 -ac 2 -i "${latestPcm}" "${wavPath}"`);
  } catch (err) {
    console.error('❌ FFmpeg error:', err);
    return interaction.editReply('❌ Failed to convert audio.');
  }
  logStep('PCM → WAV', t2);

  // Step 4: Transcribe
  const t3 = now();
  let transcript = '';
  try {
    execSync(
        `whisper "${wavPath}" --model tiny --language en --task transcribe --output_format txt --output_dir "${wavsDir}"`,
        { encoding: 'utf8' }
    );
  } catch (err) {
    console.error('❌ Whisper error:', err);
    return interaction.editReply('❌ Failed to transcribe.');
  }
  logStep('Whisper transcription', t3);

  if (!transcript) {
    return interaction.editReply('❌ Transcription was empty.');
  }

  // Step 5: LLM generation
  const t4 = now();
  let replyText = '';
  try {
    replyText = await queryOllama(transcript);
  } catch (err) {
    console.error('❌ LLM error:', err);
    return interaction.editReply('❌ LLM generation failed.');
  }
  logStep('LLM response (Ollama)', t4);

  // Step 6: TTS
  const t5 = now();
  try {
    await textToSpeech(replyText);
  } catch (err) {
    console.error('❌ TTS error:', err);
    return interaction.editReply('❌ Failed to synthesize audio.');
  }
  logStep('TTS (ElevenLabs)', t5);

  // Step 7: Playback
  const t6 = now();
  try {
    await playAudioInChannel(guild.id, audioOutPath);
  } catch (err) {
    console.error('❌ Playback error:', err);
    return interaction.editReply('❌ Failed to play audio.');
  }
  logStep('Audio playback', t6);

  logStep('✅ TOTAL TIME', globalStart);
  await interaction.editReply(`✅ Walter White says:\n> ${replyText}`);
}