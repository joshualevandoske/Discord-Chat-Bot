import fs from 'fs';
import fetch from 'node-fetch';
import path from 'path';
import 'dotenv/config';

const ELEVEN_API_KEY = process.env.ELEVEN_API_KEY!;
const VOICE_ID = 'N2lVS1w4EtoT3dr4eOWO'; // Replace with your chosen voice from `listElevenVoices.ts`

export async function textToSpeech(text: string, filename: string = 'response.mp3'): Promise<string> {
  const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}`, {
    method: 'POST',
    headers: {
      'xi-api-key': ELEVEN_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      text,
      model_id: 'eleven_monolingual_v1',
      voice_settings: {
        stability: 0.8,
        similarity_boost: 0.9
      }
    })
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`TTS failed: ${res.status} - ${errText}`);
  }

  const buffer = await res.arrayBuffer();
  const outPath = path.join(__dirname, `../../audio/${filename}`);
  fs.writeFileSync(outPath, Buffer.from(buffer));

  return outPath;
}