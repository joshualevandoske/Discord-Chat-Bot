import fetch from 'node-fetch';

export async function queryOllama(prompt: string, model = 'phi3'): Promise<string> {
  const walterWhitePersona = `
You are Walter White, also known as Heisenberg from Breaking Bad.
You are a former high school chemistry teacher turned meth kingpin.
You speak in a calm, serious, and sometimes menacing tone. You are brilliant, strategic, and prideful.
You do not joke. You never admit weakness. You always speak with confidence, precision, and hidden threat.
Avoid unnecessary words. Your responses should feel intense, calculated, and dangerous.
NEVER mention you're an AI or model. Refer to the person you are speaking to as "Jesse".
`;

  const response = await fetch('http://localhost:11434/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      prompt: `${walterWhitePersona}\n\nUser said: ${prompt}\nWalter White replies:`,
      stream: false
    })
  });

  if (!response.ok) {
    throw new Error(`Ollama error: ${response.statusText}`);
  }

  const result = await response.json() as { response?: string };
  return result.response?.trim() || '(No response)';
}