import fetch from 'node-fetch';
import 'dotenv/config';

const ELEVEN_API_KEY = process.env.ELEVEN_API_KEY;

(async () => {
  if (!ELEVEN_API_KEY) {
    console.error("❌ Missing ELEVEN_API_KEY in .env");
    process.exit(1);
  }

  const res = await fetch('https://api.elevenlabs.io/v1/voices', {
    headers: {
      'xi-api-key': ELEVEN_API_KEY,
    }
  });

  const json = await res.json() as { voices?: { name: string; voice_id: string }[] };

  if (!json.voices) {
    console.error("❌ Unexpected response from ElevenLabs:");
    console.error(json);
    return;
  }

  console.log('🎙 Available Voices:');
  json.voices.forEach((v: any) =>
    console.log(`${v.name}: ${v.voice_id}`)
  );
})();