import { playAudioInChannel } from '../src/audio/playback';

const GUILD_ID = '881023053264486421'; // Replace this with your actual server ID
const filePath = 'audio/response.mp3'; // Path to your Walter audio

playAudioInChannel(GUILD_ID, filePath);