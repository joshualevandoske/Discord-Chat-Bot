import fs from 'fs';
import path from 'path';
import { queryOllama } from '../src/llm/ollamaClient';

const transcriptFile = path.join(__dirname, '../wavs/example.txt'); // change filename

if (!fs.existsSync(transcriptFile)) {
  console.error('❌ Transcript file not found:', transcriptFile);
  process.exit(1);
}

const prompt = fs.readFileSync(transcriptFile, 'utf-8');

queryOllama(prompt).then(response => {
  console.log('\n🧠 Ollama response:\n', response);
}).catch(err => {
  console.error('❌ Failed to get response from Ollama:', err);
});