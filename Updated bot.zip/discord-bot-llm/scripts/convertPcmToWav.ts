import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';

// Forcefully define root path to project
const ROOT_DIR = path.resolve(__dirname, '..'); // 👈 adjust as needed
const RECORDINGS_DIR = path.join(ROOT_DIR, 'recordings');
const OUTPUT_DIR = path.join(ROOT_DIR, 'wavs');

// Debug print paths
console.log("RECORDINGS_DIR =", RECORDINGS_DIR);
console.log("OUTPUT_DIR =", OUTPUT_DIR);

// Make sure output folder exists
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR);
}

// Convert each `.pcm` to `.wav` using ffmpeg
fs.readdirSync(RECORDINGS_DIR).forEach((file) => {
  if (!file.endsWith('.pcm')) return;

  const inputPath = path.join(RECORDINGS_DIR, file);
  const outputFilename = file.replace('.pcm', '.wav');
  const outputPath = path.join(OUTPUT_DIR, outputFilename);

  console.log(`🎛️ Converting ${file} → ${outputFilename}...`);

  const ffmpeg = spawn('ffmpeg', [
    '-f', 's16le',
    '-ar', '48000',
    '-ac', '2',
    '-i', inputPath,
    outputPath
  ]);

  ffmpeg.stderr.on('data', (data) => process.stderr.write(data));
  ffmpeg.on('close', (code) => {
    if (code === 0) {
      console.log(`✅ Done: ${outputFilename}`);
    } else {
      console.error(`❌ ffmpeg exited with code ${code}`);
    }
  });
});