import { textToSpeech } from '../src/tts/elevenLabsClient';

(async () => {
  try {
    const filePath = await textToSpeech("I am the one who knocks.");
    console.log("✅ TTS saved to:", filePath);
  } catch (err) {
    console.error("❌ Failed to generate TTS:", err);
  }
})();