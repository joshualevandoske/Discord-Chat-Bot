import { REST, Routes } from 'discord.js';
import 'dotenv/config';

const clientId = process.env.DISCORD_LLM_BOT_CLIENT_ID!;
const token = process.env.DISCORD_LLM_BOT_TOKEN!;
const guildId = process.env.GUILD_ID!;

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    const commands: any = await rest.get(Routes.applicationGuildCommands(clientId, guildId));
    console.log(`Found ${commands.length} guild command(s).`);

    for (const command of commands) {
      console.log(`🗑️ Deleting guild command: /${command.name}`);
      await rest.delete(
        `${Routes.applicationGuildCommands(clientId, guildId)}/${command.id}`
      );
    }

    console.log("✅ All guild commands deleted.");
  } catch (err) {
    console.error("❌ Failed to delete guild commands:", err);
  }
})();